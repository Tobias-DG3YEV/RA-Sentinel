// (c) Copyright 2014, 2023 Advanced Micro Devices, Inc. All rights reserved.
//
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
////////////////////////////////////////////////////////////
//
//  Note the following:
//   * In MEX functions mxMalloc/mxCalloc/mxRealloc will not return if the allocation fails,
//       hence checks for null pointers are unnecessary
//   * Matlab performs automatic garbage collection of non-persistent memory and arrays within MEX functions,
//       hence calls to mxFree are generally not required

#include "mex.h"
#include "div_gen_v5_1_bitacc_cmodel.h"
#include <stdlib.h>
#include <string.h>

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//mxarray helper functions

//True if mx can be interpreted as a real numeric scalar
bool is_real_scalar(const mxArray* mx)
{
  return mx && mxGetNumberOfElements(mx)==1 && mxIsNumeric(mx) && !mxIsComplex(mx) && !mxIsSparse(mx);
}

//True if mx can be interpreted as a real numeric vector
bool is_numeric_vector(const mxArray* mx)
{
  return mx && mxIsNumeric(mx) && !mxIsSparse(mx);
}

//True if mx can be interpreted as a single string
bool is_string(const mxArray* mx)
{
  return mx && mxIsChar(mx) && mxGetM(mx)==1 && mxGetN(mx)==mxGetNumberOfElements(mx);
}

//Concatenate two C style strings in an mxMalloc allocated area of memory
char* mxmalloc_strcat(const char* s1,const char* s2)
{
  size_t s1len;
  size_t s2len;
  char* res;

  s1len=strlen(s1);
  s2len=strlen(s2);
  res=(char*)mxMalloc(s1len+s2len+1);

  strcpy(res      ,s1);
  strcpy(res+s1len,s2);

  return res;
}

//Convert an mxArray to a C-style string
char* mxarray_to_string(const mxArray* mx)
{
  char* res;
  unsigned int res_len;

  if (!is_string(mx)) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_string","ERROR:div_gen_v5_1_bitacc_mex:Expecting string");

  res_len=(unsigned int)mxGetNumberOfElements(mx)+1;
  res=(char*)mxMalloc(res_len);

  if (mxGetString(mx,res,res_len)) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_call","ERROR:div_gen_v5_1_bitacc_mex:Unexpected failure of mxGetString");
  return res;
}

//Convert a numeric real scalar mxArray to an int
int mxarray_to_int(const mxArray* mx)
{
  if (is_real_scalar(mx))
  {
    double x=mxGetScalar(mx);
    return (int)(x);
  }
  else if (mxIsLogicalScalar(mx))
  {
    //Convert logical to 0 or 1
    return (mxIsLogicalScalarTrue(mx) ? 1 : 0);
  }

  mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_scalar","ERROR:div_gen_v5_1_bitacc_mex:Expecting real numeric or logical scalar");
  return 0;  //Will not return
}

//Convert a numeric real scalar mxArray to an unsigned int
unsigned int mxarray_to_uint(const mxArray* mx)
{
  if (is_real_scalar(mx))
  {
    double x=mxGetScalar(mx);
    if (x>=0.0) return (unsigned int)(x);
  }
  else if (mxIsLogicalScalar(mx))
  {
    //Convert logical to 0 or 1
    return (mxIsLogicalScalarTrue(mx) ? 1 : 0);
  }

  mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_scalar","ERROR:div_gen_v5_1_bitacc_mex:Expecting unsigned real numeric or logical scalar");
  return 0;  //Will not return
}

//Create a real numeric scalar with the given value
mxArray* mxarray_create_scalar(double value)
{
  mxArray* res=mxCreateDoubleScalar(value);
  if (!res) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_scalar","ERROR:div_gen_v5_1_bitacc_mex:Could not create numeric scalar");
  return res;
}

//Create an empty scalar structure
mxArray* mxstruct_create()
{
  const char* FIELDNAMES[]={""};
  mxArray* res=mxCreateStructMatrix(1,1,0,FIELDNAMES);
  if (!res) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_struct","ERROR:div_gen_v5_1_bitacc_mex:Could not create empty structure");
  return res;
}

//Add a string field to an mxarray struct
void mxstruct_add_field_string(mxArray* mx, const char* fieldname, const char* value)
{
  int ix=mxAddField(mx,fieldname);
  if (ix==-1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_field","ERROR:div_gen_v5_1_bitacc_mex:Could not add field %s",fieldname);
  mxSetFieldByNumber(mx,0,ix,mxCreateString(value));
}

//Add an integer field to an mxarray struct
void mxstruct_add_field_int(mxArray* mx, const char* fieldname, int value)
{
  int ix=mxAddField(mx,fieldname);
  if (ix==-1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_field","ERROR:div_gen_v5_1_bitacc_mex:Could not add field %s",fieldname);
  mxSetFieldByNumber(mx,0,ix,mxCreateDoubleScalar((double)value));
}

//Add an unsigned integer field to an mxarray struct
void mxstruct_add_field_uint(mxArray* mx, const char* fieldname, unsigned int value)
{
  int ix=mxAddField(mx,fieldname);
  if (ix==-1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_field","ERROR:div_gen_v5_1_bitacc_mex:Could not add field %s",fieldname);
  mxSetFieldByNumber(mx,0,ix,mxCreateDoubleScalar((double)value));
}

//Add a mxarray field to an mxarray struct
void mxstruct_add_field_mxarray(mxArray* mx, const char* fieldname, const mxArray* mx_value)
{
  int ix=mxAddField(mx,fieldname);
  if (ix==-1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_field","ERROR:div_gen_v5_1_bitacc_mex:Could not add field %s",fieldname);
  mxSetFieldByNumber(mx,0,ix,(mxArray*)mx_value);
}

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//Functions for manipulating model handles

//Model handle type
typedef unsigned int model_handle;

//Simple dynamic vector for storing model structures attached to model handles
typedef struct
{
  xip_div_gen_v5_1** m_data;
  size_t m_size;
} model_handle_vector;

//Destroy a model_handle_vector
void model_handle_vector_destroy(model_handle_vector* mhv)
{
  size_t i;

  if (mhv)
  {
    //Destroy any model objects in the model_handle_vector
    if (mhv->m_data)
    {
      for (i=0; i<mhv->m_size; i++)
      {
        if (mhv->m_data[i]) xip_div_gen_v5_1_destroy(mhv->m_data[i]);
      }

      free(mhv->m_data);
    }

    free(mhv);
  }
}

//Create a model_handle_vector
model_handle_vector* model_handle_vector_create()
{
  const unsigned int DEFAULT_SIZE=16;
  model_handle_vector* mhv;

  mhv=(model_handle_vector*)calloc(1,sizeof(model_handle_vector));
  if (mhv)
  {
    mhv->m_data=(xip_div_gen_v5_1**)calloc(DEFAULT_SIZE,sizeof(xip_div_gen_v5_1*));
    mhv->m_size=DEFAULT_SIZE;
  }

  if (!mhv || !mhv->m_data)
  {
    model_handle_vector_destroy(mhv);
    mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_alloc","ERROR:div_gen_v5_1_bitacc_mex:Could not allocate memory for model handle vector");
    return 0;
  }

  return mhv;
}

//Get next unused model_handle in model_handle_vector
model_handle model_handle_vector_get_next(model_handle_vector* mhv)
{
  model_handle res=0;
  xip_div_gen_v5_1** p=0;

  //Scan array looking for free slot (handle 0 is always unused)
  for (res=1; res<mhv->m_size; res++) if (!mhv->m_data[res]) return res;

  //No spare slot found in array, so extend it
  p=(xip_div_gen_v5_1**)realloc((void*)mhv->m_data,sizeof(xip_div_gen_v5_1*)*mhv->m_size*2);
  if (!p) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_model_handle","ERROR:div_gen_v5_1_bitacc_mex:Could not allocate a free model handle");

  //Resize was successful
  memset((void*)(p+mhv->m_size),0,sizeof(xip_div_gen_v5_1*)*mhv->m_size);
  res=(model_handle)mhv->m_size;
  mhv->m_data=p;
  mhv->m_size=mhv->m_size*2;
  return res;
}

//Set xip_div_gen_v5_1 associated with model_handle
void model_handle_vector_set_structure(model_handle_vector* mhv, model_handle mh, xip_div_gen_v5_1* s)
{
  if (mh>0 && mh<mhv->m_size) mhv->m_data[mh]=s;
}

//Get xip_div_gen_v5_1 associated with model_handle
xip_div_gen_v5_1* model_handle_vector_get_structure(model_handle_vector* mhv, model_handle mh)
{
  if (mh>0 && mh<mhv->m_size) return mhv->m_data[mh];
  return 0;
}

//Get a model_handle from the numeric scalar array mx (or zero if error or invalid)
model_handle mxarray_get_model_handle(const mxArray* mx)
{
  if (!is_real_scalar(mx))
  {
    mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_model_handle","ERROR:div_gen_v5_1_bitacc_mex:Model handle must be a real numeric scalar");
    return 0;
  }

  //Get handle as an integer
  return (model_handle)mxGetScalar(mx);
}

//Global model_handle_vector for this MEX function
model_handle_vector* the_model_handle_vector=0;

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//Functions for converting between Matlab and Xilinx arrays

//Convert dimensions vector from mwSize* to size_t*
const size_t* mxarray_dimensions_to_xip_array_dimensions(const mxArray* mx)
{
  size_t* res;
  mwSize len;
  const mwSize* p;
  const mwSize* q;
  size_t* r;

  if (sizeof(size_t)==sizeof(mwSize))
  {
    //If sizeof(mwSize)==sizeof(size_t) the vector can be used directly (read only)
    return (const size_t*)mxGetDimensions(mx);
  }
  else
  {
    //Otherwise we need a copy
    len=mxGetNumberOfDimensions(mx);
    res=(size_t*)mxMalloc(len*sizeof(size_t));
    for (p=mxGetDimensions(mx), q=p+len, r=res; p!=q; ++p, ++r) *r=*p;
    return res;
  }
}

//Convert dimensions vector from size_t* to mwSize*
const mwSize* xip_array_dimensions_to_mxarray_dimensions(const size_t* dim, const size_t dim_size)
{
  mwSize* res;
  const size_t* p;
  const size_t* q;
  mwSize* r;

  if (sizeof(size_t)==sizeof(mwSize))
  {
    //If sizeof(mwSize)==sizeof(size_t) the vector can be used directly (read only)
    return (const mwSize*)dim;
  }
  else
  {
    //Otherwise we need a copy
    res=(mwSize*)mxMalloc(dim_size*sizeof(mwSize));
    for (p=dim, q=p+dim_size, r=res; p!=q; ++p, ++r) *r=(mwSize)(*p);
    return res;
  }
}

//Convert a mxArray to a static xip_array_uint
xip_array_uint* mxarray_to_xip_array_uint(const mxArray* mx, const char* name)
{
  xip_array_uint* res=0;

  //Create an empty xip_array object on the Matlab heap
  res=(xip_array_uint*)mxCalloc(1,sizeof(xip_array_uint));
  res->owner=1;  //Memory is owned by Matlab
  res->ops=xip_array_uint_get_default_ops();

  if (mx)
  {
    if (!is_numeric_vector(mx) || mxIsComplex(mx)) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_array","ERROR:div_gen_v5_1_bitacc_mex:Invalid %s; expecting unsigned int vector",name);
    if (mxGetClassID(mx)!=mxUINT32_CLASS) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_array","ERROR:div_gen_v5_1_bitacc_mex:Invalid %s; expecting class unsigned int",name);
    
    //Create xip_array
    res->data         =(unsigned int*)mxGetData(mx); // Cast to unsigned int
    res->data_size    =mxGetNumberOfElements(mx);
    res->data_capacity=mxGetNumberOfElements(mx);
    res->dim          =(size_t*)mxarray_dimensions_to_xip_array_dimensions(mx);  //Discard const qualifier, however model will not modify as owner is not zero
    res->dim_size     =mxGetNumberOfDimensions(mx);
    res->dim_capacity =mxGetNumberOfDimensions(mx);
  }
  
  return res;
}

//Convert a mxArray to a static xip_array_real
xip_array_real* mxarray_to_xip_array_real(const mxArray* mx, const char* name)
{
  xip_array_real* res=0;

  //Create an empty xip_array object on the Matlab heap
  res=(xip_array_real*)mxCalloc(1,sizeof(xip_array_real));
  res->owner=1;  //Memory is owned by Matlab
  res->ops=xip_array_real_get_default_ops();

  if (mx)
  {
    if (!is_numeric_vector(mx) || mxIsComplex(mx)) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_array","ERROR:div_gen_v5_1_bitacc_mex:Invalid %s; expecting real vector",name);
    if (mxGetClassID(mx)!=mxDOUBLE_CLASS) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_array","ERROR:div_gen_v5_1_bitacc_mex:Invalid %s; expecting class double",name);

    //Create xip_array
    //  xip_array_real uses same data representation as mxarray, so we can link directly to Matlab data
    res->data         =mxGetPr(mx);
    res->data_size    =mxGetNumberOfElements(mx);
    res->data_capacity=mxGetNumberOfElements(mx);
    res->dim          =(size_t*)mxarray_dimensions_to_xip_array_dimensions(mx);  //Discard const qualifier, however model will not modify as owner is not zero
    res->dim_size     =mxGetNumberOfDimensions(mx);
    res->dim_capacity =mxGetNumberOfDimensions(mx);
  }

  return res;
}

//Convert a xip_array_real to a mxArray
mxArray* xip_array_real_to_mxarray(const xip_array_real* x)
{
  mxArray* res;
  const xip_real* p;
  const xip_real* q;
  double* r;

  res=mxCreateNumericArray((int)x->dim_size,xip_array_dimensions_to_mxarray_dimensions(x->dim,x->dim_size),mxDOUBLE_CLASS,mxREAL);
  for (p=x->data, q=x->data+mxGetNumberOfElements(res), r=(double*)mxGetPr(res); p!=q; ++p, ++r) *r=(double)*p;
  return res;
}

//Convert a xip_array_real to a mxArray
mxArray* xip_array_uint_to_mxarray(const xip_array_uint* x)
{
  mxArray* res;
  const xip_uint* p;
  const xip_uint* q;
  unsigned int* r;

  res=mxCreateNumericArray((int)x->dim_size,xip_array_dimensions_to_mxarray_dimensions(x->dim,x->dim_size),mxUINT32_CLASS,mxREAL);
  for (p=x->data, q=x->data+mxGetNumberOfElements(res), r=(unsigned int*)mxGetPr(res); p!=q; ++p, ++r) *r=(unsigned int)*p;
  return res;
}

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//Functions to handle xip_div_gen_v5_1_* structures

//Convert a mxArray to a xip_div_gen_v5_1_config structure
xip_div_gen_v5_1_config* mxarray_to_xip_div_gen_v5_1_config(const mxArray* mx, const char* name)
{
  xip_div_gen_v5_1_config* res=0;
  int i;

  res=(xip_div_gen_v5_1_config*)mxCalloc(1,sizeof(xip_div_gen_v5_1_config));
  xip_div_gen_v5_1_default_config(res);

  if (mx)
  {
    if (!mxIsStruct(mx) || mxGetNumberOfElements(mx)!=1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_structure","ERROR:div_gen_v5_1_bitacc_mex:Invalid %s; expecting scalar structure",name);

    for (i=0; i<mxGetNumberOfFields(mx); i++)
    {
      const char* fieldname=mxGetFieldNameByNumber(mx,i);
           if (!strcmp(fieldname,"name"               )) res->name                =mxarray_to_string(mxGetFieldByNumber(mx,0,i));
      else if (!strcmp(fieldname,"algorithm_type"     )) res->algorithm_type      =mxarray_to_int   (mxGetFieldByNumber(mx,0,i));
      else if (!strcmp(fieldname,"divisor_width"      )) res->divisor_width       =mxarray_to_int   (mxGetFieldByNumber(mx,0,i));
      else if (!strcmp(fieldname,"dividend_width"     )) res->dividend_width      =mxarray_to_int   (mxGetFieldByNumber(mx,0,i));
      else if (!strcmp(fieldname,"operand_sign"       )) res->operand_sign        =mxarray_to_int   (mxGetFieldByNumber(mx,0,i));
      else if (!strcmp(fieldname,"remainder_type"     )) res->remainder_type      =mxarray_to_int   (mxGetFieldByNumber(mx,0,i));
      else if (!strcmp(fieldname,"fractional_width"   )) res->fractional_width    =mxarray_to_int   (mxGetFieldByNumber(mx,0,i));
      else if (!strcmp(fieldname,"clocks_per_division")) res->clocks_per_division =mxarray_to_int   (mxGetFieldByNumber(mx,0,i));
      else if (!strcmp(fieldname,"debug"              )) res->debug               =mxarray_to_int   (mxGetFieldByNumber(mx,0,i));
      else mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_fieldname","ERROR:div_gen_v5_1_bitacc_mex:Invalid %s; unexpected fieldname %s",name,fieldname);
    }
  }

  return res;
}

//Convert a xip_div_gen_v5_1_config structure to a mxArray
mxArray* xip_div_gen_v5_1_config_to_mxarray(const xip_div_gen_v5_1_config* s)
{
  mxArray* mx;
  
  //Create structure and populate
  mx=mxstruct_create();
  mxstruct_add_field_string(mx,"name",s->name);
  mxstruct_add_field_int(mx,"algorithm_type"      ,s->algorithm_type);
  mxstruct_add_field_int(mx,"divisor_width"       ,s->divisor_width);
  mxstruct_add_field_int(mx,"dividend_width"      ,s->dividend_width);
  mxstruct_add_field_int(mx,"operand_sign"        ,s->operand_sign);
  mxstruct_add_field_int(mx,"remainder_type"      ,s->remainder_type);
  mxstruct_add_field_int(mx,"fractional_width"    ,s->fractional_width);
  mxstruct_add_field_int(mx,"clocks_per_division" ,s->clocks_per_division);
  mxstruct_add_field_int(mx,"debug"               ,s->debug);
  
  return mx;
}

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//Main body of MEX function

//Opcodes
typedef enum
{
  OP_GET_VERSION=0,
  OP_GET_DEFAULT_CONFIG=1,
  OP_CREATE=2,
  OP_DESTROY=3,
  OP_DIVIDE=4,
  OP_GET_CONFIG=5,
} mex_opcode;

//Called at MEX exit
void mex_at_exit()
{
  //Destroy all outstanding model objects
  model_handle_vector_destroy(the_model_handle_vector);
}

//Pass messages to Matlab
void mex_message_handler(void* handle, int error, const char* msg)
{
  if (error)
  {
    mexErrMsgTxt(msg);
  }
  else
  {
    mexPrintf("%s\n",msg);
  }
}

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void do_get_version(mex_opcode opcode, int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
  if (nrhs!=0) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_input","ERROR:div_gen_v5_1_bitacc_mex:get_version:Expecting zero input arguments");

  plhs[0]=mxCreateString(xip_div_gen_v5_1_get_version());
  if (!plhs[0])
  {
    mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_string","ERROR:div_gen_v5_1_bitacc_mex:get_version:Could not create string array");
    return;
  }
}

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void do_get_default_config(mex_opcode opcode, int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
  xip_div_gen_v5_1_config* config;

  if (nrhs!=0) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_input","ERROR:div_gen_v5_1_bitacc_mex:get_default_config:Expecting zero input arguments");

  //Convert default config to mxArray structure
  config=mxarray_to_xip_div_gen_v5_1_config(0,"default_config");
  plhs[0]=xip_div_gen_v5_1_config_to_mxarray(config);
  mxFree(config);
}

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void do_create(mex_opcode opcode, int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
  xip_div_gen_v5_1_config* config;
  model_handle mh;
  xip_div_gen_v5_1* model;

  if (nrhs!=1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_input","ERROR:div_gen_v5_1_bitacc_mex:create:Expecting one input argument");

  //Get config
  config=mxarray_to_xip_div_gen_v5_1_config(prhs[0],"config");

  //Get next model_handle to use
  mh=model_handle_vector_get_next(the_model_handle_vector);

  //Now create the model
  model=xip_div_gen_v5_1_create(config,mex_message_handler,0);
  if (!model) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_create","ERROR:div_gen_v5_1_bitacc_mex:create:Could not create model");

  //Register pointer and return handle
  model_handle_vector_set_structure(the_model_handle_vector,mh,model);
  plhs[0]=mxarray_create_scalar(mh);
}

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void do_destroy(mex_opcode opcode, int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
  model_handle mh;
  xip_div_gen_v5_1* model;

  if (nrhs!=1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_input","ERROR:div_gen_v5_1_bitacc_mex:destroy:Expecting one input argument");
  if (nlhs!=0) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_output","ERROR:div_gen_v5_1_bitacc_mex:destroy:Expecting zero output arguments");

  //Get model_handle
  mh=mxarray_get_model_handle(prhs[0]);
  model=model_handle_vector_get_structure(the_model_handle_vector,mh);

  //Destroy object if it still exists
  xip_div_gen_v5_1_destroy(model);
  model_handle_vector_set_structure(the_model_handle_vector,mh,0);
}

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void do_divide(mex_opcode opcode, int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
  model_handle mh;
  xip_div_gen_v5_1* model;
  xip_array_real *dividend;
  xip_array_real *divisor;
  xip_array_real *quotient;
  xip_array_real *remainder;
  xip_array_uint *div_by_zero;
  xip_uint       number_of_samples;
  
  // xip_div_gen_v5_1_config config;
  
  
  // Get model_handle
  mh=mxarray_get_model_handle(prhs[0]);
  model=model_handle_vector_get_structure(the_model_handle_vector,mh);
  if (!model) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_model_handle","ERROR:div_gen_v5_1_bitacc_mex:data_do:Invalid model pointer");
  // Get config to check remainder type as it influences how many values we return
  // xip_div_gen_v5_1_get_config(model,&config);
  
  // Check input arguments
  if (nrhs!=3) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_input","ERROR:div_gen_v5_1_bitacc_mex:data_do:Expecting two input arguments");
  // if (config.remainder_type == XIP_DIV_GEN_V5_1_REMTYPE_FRACTIONAL) {
    // if (nlhs<1 || nlhs>2 ) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_output","ERROR:div_gen_v5_1_bitacc_mex:data_do:Expecting one or two output arguments");
  // } else {
    // if (nlhs<1 || nlhs>3 ) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_output","ERROR:div_gen_v5_1_bitacc_mex:data_do:Expecting one to three output arguments");
  // }
  if (nlhs != 3 ) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_output","ERROR:div_gen_v5_1_bitacc_mex:data_do:Expecting three output arguments");
  
  // Inputs
  dividend = mxarray_to_xip_array_real(prhs[1],"dividend");
  divisor  = mxarray_to_xip_array_real(prhs[2],"divisor");
  // Use the dividend input as the master array for size
  number_of_samples = dividend->data_size;
  
  // Create and allocate space for output arrays
  quotient      = xip_array_real_create();
  xip_array_real_reserve_dim(quotient,dividend->dim_size);
  quotient->dim_size = dividend->dim_size;
  for (int i = 0;i < dividend->dim_size;i++) {
    quotient->dim[i] = dividend->dim[i];
  }
  xip_array_real_reserve_data(quotient,dividend->data_size);
  quotient->data_size = dividend->data_size;
  
  remainder     = xip_array_real_create();
  xip_array_real_reserve_dim(remainder,dividend->dim_size);
  remainder->dim_size = dividend->dim_size;
  for (int i = 0;i < dividend->dim_size;i++) {
    remainder->dim[i] = dividend->dim[i];
  }
  xip_array_real_reserve_data(remainder,dividend->data_size);
  remainder->data_size = dividend->data_size;
  
  div_by_zero   = xip_array_uint_create();
  xip_array_uint_reserve_dim(div_by_zero,dividend->dim_size);
  div_by_zero->dim_size = dividend->dim_size;
  for (int i = 0;i < dividend->dim_size;i++) {
    div_by_zero->dim[i] = dividend->dim[i];
  }
  xip_array_uint_reserve_data(div_by_zero,dividend->data_size);
  div_by_zero->data_size = dividend->data_size;
  
  // Run model
  xip_div_gen_v5_1_data_real_do(model, divisor, dividend, quotient, remainder, div_by_zero, number_of_samples);
  
  //Convert results to mxarray and assign to outputs
  plhs[0]=xip_array_real_to_mxarray(quotient);
  plhs[1]=xip_array_real_to_mxarray(remainder);
  plhs[2]=xip_array_uint_to_mxarray(div_by_zero);
  // if (nlhs >1) {
    // if (config.remainder_type == XIP_DIV_GEN_V5_1_REMTYPE_FRACTIONAL) {
      // plhs[1]=xip_array_real_to_mxarray(div_by_zero);
    // } else {
      // plhs[1]=xip_array_real_to_mxarray(remainder);
    // }
  // }
  // if (nlhs >2) {
    // plhs[2]=xip_array_real_to_mxarray(div_by_zero);
  // }
  xip_array_real_destroy(quotient);
  xip_array_real_destroy(remainder);
  xip_array_uint_destroy(div_by_zero);
  mxFree(divisor);
  mxFree(dividend);
}
//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void do_get_config(mex_opcode opcode, int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
  model_handle mh;
  xip_div_gen_v5_1* model;
  xip_div_gen_v5_1_config* config;
  
  config=(xip_div_gen_v5_1_config*)mxCalloc(1,sizeof(xip_div_gen_v5_1_config));
  
  if (nrhs!=1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_input","ERROR:div_gen_v5_1_bitacc_mex:get_config:Expecting one input argument");
  if (nlhs!=1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_output","ERROR:div_gen_v5_1_bitacc_mex:get_config:Expecting one output argument");
  
  // Get model_handle
  mh=mxarray_get_model_handle(prhs[0]);
  model=model_handle_vector_get_structure(the_model_handle_vector,mh);
  if (!model) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_model_handle","ERROR:div_gen_v5_1_bitacc_mex:do_get_config:Invalid model pointer");
  
  xip_div_gen_v5_1_get_config(model,config);
  
  //Convert results to mxarray
  plhs[0]=xip_div_gen_v5_1_config_to_mxarray(config);
  mxFree(config);
}
//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
  double x;
  mex_opcode opcode;

  //First time initialisation
  if (!the_model_handle_vector)
  {
    //Register our exit function
    mexAtExit(mex_at_exit);

    //Ensure datatypes are equivalent
    if (sizeof(xip_uint)!=sizeof(unsigned int )) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_mex","ERROR:div_gen_v5_1_bitacc_mex:Invalid MEX function; size of xip_uint and unsigned int types are incompatible");
    if (sizeof(xip_real)!=sizeof(double       )) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_mex","ERROR:div_gen_v5_1_bitacc_mex:Invalid MEX function; size of xip_real and double types are incompatible");

    //Create model repository
    the_model_handle_vector=model_handle_vector_create();
  }

  //Consume and check opcode
  if (nrhs<1) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_opcode","ERROR:div_gen_v5_1_bitacc_mex:Missing opcode");
  if (!is_real_scalar(prhs[0])) mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_opcode","ERROR:div_gen_v5_1_bitacc_mex:opcode must be a real numeric scalar");
  x=mxGetScalar(prhs[0]);
  opcode=(mex_opcode)((int)x);
  nrhs--;
  prhs++;

  //Dispatch opcode
  switch (opcode)
  {
    case OP_GET_VERSION:
    {
      do_get_version(opcode,nlhs,plhs,nrhs,prhs);
    } break;

    case OP_GET_DEFAULT_CONFIG:
    {
      do_get_default_config(opcode,nlhs,plhs,nrhs,prhs);
    } break;

    case OP_CREATE:
    {
      do_create(opcode,nlhs,plhs,nrhs,prhs);
    } break;

    case OP_DESTROY:
    {
      do_destroy(opcode,nlhs,plhs,nrhs,prhs);
    } break;

    case OP_DIVIDE:
    {
      do_divide(opcode,nlhs,plhs,nrhs,prhs);
    } break;

    case OP_GET_CONFIG:
    {
      do_get_config(opcode,nlhs,plhs,nrhs,prhs);
    } break;

    default:
    {
      mexErrMsgIdAndTxt("div_gen_v5_1_bitacc_mex:bad_opcode","ERROR:div_gen_v5_1_bitacc_mex:Invalid opcode %d",opcode);
    } break;
  }
}
